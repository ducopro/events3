<html>
<body>
<h1>Password Reset</h1>
<p>On request your password has been reset to: <?php print $cNewPassword?></p>
<p>You can login to the system using this email adress and the new password.</p>
<p>For your convenience you can click <a href="<?php print $cLink ?>">here</a> to go to the loginpage with your emailaddress and password prefilled.</p>
<br />
<p>Administrator</p>
</body>
</html>