<div class="col-sm-3">
  <div class="panel <?php print $class;?>">
    <div class="panel-heading">
    <h4><?php print $title;?></h4>
    </div>
    <div class="panel-body">
    <?php print $deploy;?><br />
    <?php print $fileinfo;?><br />
    <?php print $password;?><br />
    <?php print $edit;?><br />
    <?php print $backup;?><br />
    </div>
  </div>
</div>