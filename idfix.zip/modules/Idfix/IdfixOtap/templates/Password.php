<div class="well">
    <form class="form-signin" role="form">
            <h4 class="form-signin-heading">Change Admin Password</h4>
            <input type="password" class="form-control" placeholder="Password" required>
            <input type="password" class="form-control" placeholder="Password again" required><br />
            <button class="btn btn-primary " type="submit">Change</button>
    </form>
</div>