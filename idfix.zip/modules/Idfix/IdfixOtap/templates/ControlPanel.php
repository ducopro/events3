<div class="well">
<h1><?php print $icon . $title?> <small><strong>DTAP</strong> Configuration Control Panel</small></h1>
<div class="row">
   <?php print $dev; ?>
   <?php print $test; ?>
   <?php print $accept; ?>
   <?php print $prod; ?>
</div>
</div>