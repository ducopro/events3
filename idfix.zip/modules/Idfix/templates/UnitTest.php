<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 3.2//EN">

<html>
<head>
    <title>Testing the Idfix template system</title>
</head>

<body>
Hello Idfix
</body>
</html>
