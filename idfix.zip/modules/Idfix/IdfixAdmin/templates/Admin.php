<div class="well">
    
    <h1><?php print $icon . $title?> 
        <small>
            <strong>ADMIN</strong> 
            Console
        </small>
    </h1>

    <div class="row">
       <?php print $menu; ?>
       <?php print $content; ?>
    </div>

</div>