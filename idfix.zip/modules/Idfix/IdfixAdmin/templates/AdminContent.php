<div class="col-sm-10">
<?php print $content; ?>
<br /><br /><br /><br /><br />
</div>