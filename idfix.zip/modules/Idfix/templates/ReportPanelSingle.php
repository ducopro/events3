<h1><?php print $data ?></h1>
<span><?php //print $sql; ?></span>