<?php
foreach($list as $item) {
    print $item;
}
?>