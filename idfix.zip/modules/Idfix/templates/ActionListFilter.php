<div class="panel panel-default"  style="overflow: hidden;">

  <div class="panel-heading">
    <p>Add Filter</p>  
     
  </div>
  
  <div class="panel-body">
    
    <form role="form" class="-form-inline" action="<?php print $cUrl;?>" method="post">
       
        
             <?php print $cInput;?>
        
        
        <div class="form-group">
        <button type="submit" class="btn btn-primary" name="button-ok">Filter</button>
        <button type="submit" class="btn btn-default" name="button-cancel">Cancel</button>
        </div

    </form>
    
    
    
  </div>

 
 

</div>