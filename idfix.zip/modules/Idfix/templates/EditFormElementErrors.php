<div class="alert alert-danger alert-dismissable">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

    <ul>
        <?php foreach($aList as $error){ print "<li>{$error}</li>"; }; ?>
    </ul>

</div>

