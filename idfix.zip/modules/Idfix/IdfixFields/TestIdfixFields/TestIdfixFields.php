<?php

class TestIdfixFields extends Events3TestCase {
    
    public function Events3Test() {
        
    }
}