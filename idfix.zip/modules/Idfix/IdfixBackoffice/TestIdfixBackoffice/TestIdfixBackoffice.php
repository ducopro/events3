<?php

/**
 * Test the backoffice system
 * 
 */ 

class TestIdfixBackoffice extends Events3TestCase {
    
    public function Events3Test() {
    }
}