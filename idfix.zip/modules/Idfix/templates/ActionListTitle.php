<?php
/**
 * $cTitle
 * $cDescription 
 * $cIcon
 */ 
?>

<h3><?php print $cIcon;?><?php print $cTitle;?>&nbsp;<small><?php print $cDescription;?></small></h3>
