<div class="center-block">
<h1><?php print $icon; ?><?php print $title; ?></h1>

<h3><em><?php print $description; ?></em></h3>
<h5>Environment: <?php print $env; ?></h5>
</div>