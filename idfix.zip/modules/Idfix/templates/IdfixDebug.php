<br /><br /><br /><br /><br />
<div class="container">
      <div class="row">
        <div class="col-lg-12">
           <div class="panel panel-danger">
               <div class="panel-heading">Idfix Debuger & profiler</div>
           <?php echo $content; ?>
           </div>
           
        </div>
      </div>
    </div>  