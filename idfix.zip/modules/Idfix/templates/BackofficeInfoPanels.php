<div class="row">

    <div class="col col-sm-12">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="panel-title"><?php print $icon1; ?> <?php print $title1; ?></h3>
          </div>
          <div class="panel-body">
            <?php print $body1; ?>
          </div>
          <div class="panel-footer">
            <?php print $footer1; ?>
          </div>
        </div>
    </div>


</div>