<div class="col-sm-2">
  <div class="panel">
    <div class="panel-heading">
    <h4>Menu</h4>
    </div>
    <div class="panel-body">
        <?php print $cOut;?><br />
    </div>
  </div>
</div>